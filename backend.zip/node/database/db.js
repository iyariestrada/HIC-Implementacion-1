import { Sequelize } from "sequelize";

const db = new Sequelize("expedientes_db", "iyari", "", {
  host: "localhost",
  dialect: "mysql",
});

export default db;
